clear

p = 4.7*2.54/100; % in m
R = 5*2.54/100; % in m 
w = 6000*(2*pi)/60; % in rad/sec
a = 5.7;
cd = 0.07;
V = 0:17;

geo_data = readmatrix("prop geometry.txt");
x_val = geo_data(:,1); % no dimension
c = R*geo_data(:,2); % in m
beta = (geo_data(:,3) + 5 )*pi/180; % in rad


Ct = zeros(length(V),1);
Cq = zeros(length(V),1);
for i = 1:length(V)

ct_tot = 0;
cq_tot = 0;

    for j=1:length(x_val)-1
        syms x
        sigma = (2*c(j)/(pi*R));
        lambda_c = (V(i)/(w*R));
        
        lambda = max(roots([1 (0.125*sigma*a - lambda_c) -0.125*sigma*a*beta(j)*x_val(j)]));

        dct =  0.5*sigma*a*(beta(j)*(x^2) - lambda*x);
        dcq =  ((0.5*sigma*a*(beta(j)*lambda*x - lambda^2)) + 0.5*sigma*cd*(x^2))*x;        

        ct_ele = int(dct,[x_val(j) x_val(j+1)]);
        cq_ele = int(dcq,[x_val(j) x_val(j+1)]);
        
        ct_tot = ct_tot + ct_ele;
        cq_tot = cq_tot + cq_ele;
    end
 
 Ct(i) = ct_tot;
 Cq(i) = cq_tot;
end

n = 6000/60; % in Rev/sec
D = 2*R; % in m
J = V/(n*D);

Ct = 0.25*(pi^3)*Ct;
Cq = 0.125*(pi^3)*Cq;
Cp = 2*pi*Cq;

act_data = readmatrix("6020.txt");

hold on;
plot(J,Ct,'DisplayName','Code Calculated Ct');
plot(J,Cp,'DisplayName','Code Calculated Cp');
plot(act_data(:,1),act_data(:,2),'DisplayName','UIUC Ct')
plot(act_data(:,1),act_data(:,3),'DisplayName','UIUC Cp')
legend