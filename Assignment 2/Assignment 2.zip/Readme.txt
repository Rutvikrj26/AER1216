Data is being read from the prop geometry and 6020.txt files. Please keep them in the same folder while running the code. 
Final Graphs are attached in the pdf answer sheet. If they don't match you runtime, please mail me : rutvik.solanki@mail.utoronto.ca
Thank you.